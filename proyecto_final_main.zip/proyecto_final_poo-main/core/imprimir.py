from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from io import BytesIO
from django.http import HttpResponse

def imprimir_generico(titulo="Reporte", subtitulo="", datos=None):
    buffer = BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=letter)
    pdf.setTitle(titulo)

    y = 750

    # Título
    pdf.setFont("Helvetica-Bold", 18)
    pdf.drawCentredString(300, y, titulo)
    y -= 30

    # Subtítulo
    if subtitulo:
        pdf.setFont("Helvetica-Bold", 12)
        pdf.drawCentredString(300, y, subtitulo)
        y -= 30

    pdf.setFont("Helvetica", 11)

    # --- TIPOS DE DATOS ---
    if isinstance(datos, dict):
        # Diccionario (clave - valor)
        for k, v in datos.items():
            pdf.drawString(50, y, f"{k}: {v}")
            y -= 20

    elif isinstance(datos, list) and len(datos) > 0 and isinstance(datos[0], dict):
        # Lista de diccionarios (TABLAS)
        headers = list(datos[0].keys())

        # Dibujar encabezados
        x = 50
        pdf.setFont("Helvetica-Bold", 11)
        for h in headers:
            pdf.drawString(x, y, str(h))
            x += 120
        y -= 20

        # Dibujar filas
        pdf.setFont("Helvetica", 11)
        for fila in datos:
            x = 50
            for h in headers:
                pdf.drawString(x, y, str(fila[h]))
                x += 120
            y -= 20

    elif isinstance(datos, list):
        # Lista simple
        for item in datos:
            pdf.drawString(50, y, f"- {item}")
            y -= 20

    else:
        # Texto o número
        pdf.drawString(50, y, str(datos))

    pdf.showPage()
    pdf.save()
    buffer.seek(0)
    return HttpResponse(buffer, content_type="application/pdf")
