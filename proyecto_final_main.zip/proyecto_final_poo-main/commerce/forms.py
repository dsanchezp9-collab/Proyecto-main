# commerce/forms.py
import datetime
from django import forms
from commerce.models import Invoice

class InvoiceForm(forms.ModelForm):
    issue_date = forms.DateTimeInput()

    class Meta:
        model = Invoice
        fields = ['customer', 'payment_method', 'issue_date', 'subtotal', 'iva', 'total']
        widgets = {
            'customer': forms.Select(),
            'payment_method': forms.Select(),
            'subtotal': forms.NumberInput(),
            'iva': forms.NumberInput(),
            'total': forms.NumberInput(),
            'issue_date': forms.DateTimeInput(
                attrs={'type': 'datetime-local'},
                format='%Y-%m-%dT%H:%M'
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Si es edición, convertir la fecha almacenada al formato datetime-local
        if self.instance and self.instance.issue_date:
            self.initial['issue_date'] = self.instance.issue_date.strftime('%Y-%m-%dT%H:%M')
        else:
            # Si es creación, usar la fecha actual
            self.initial['issue_date'] = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M')
