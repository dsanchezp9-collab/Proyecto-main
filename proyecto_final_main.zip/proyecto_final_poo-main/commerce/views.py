# commerce/views.py
from django.contrib.auth.mixins import LoginRequiredMixin
from core.mixins import TitleContextMixin
from core.models import Product
from core.utils import custom_serializer
from .forms import InvoiceForm
from .models import Invoice, InvoiceDetail
from django.db.models import Q
from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView, UpdateView, DetailView, View
from django.contrib import messages
from django.http import JsonResponse
from decimal import Decimal
from django.db import transaction
from django.template.loader import render_to_string
import json
from core.imprimir import imprimir_generico
def invoice_print(request, id):
    invoice = Invoice.objects.get(id=id)
    details = InvoiceDetail.objects.filter(invoice=invoice)

    # TABLA
    tabla = []
    for d in details:
        tabla.append({
            "Producto": d.product.description,
            "Cant": d.quantity,
            "Precio": d.price,
            "IVA": d.iva,
            "Subtotal": d.subtotal,
        })

    customer_name = (
        invoice.customer.get_full_name()
        if callable(invoice.customer.get_full_name)
        else invoice.customer.get_full_name
    )

    return imprimir_generico(
        titulo="Factura",
        subtitulo=f"Factura Nº {invoice.id} — {customer_name}",
        datos=tabla
    )
# ----------------------------------------------------------
# LISTA DE FACTURAS
# ----------------------------------------------------------
class InvoiceListView(LoginRequiredMixin, TitleContextMixin, ListView):
    model = Invoice
    template_name = 'invoice/list.html'
    context_object_name = 'invoices'
    paginate_by = 10

    title1 = "Autor | TeacherCode"
    title2 = "Listado de Ventas"

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '')
        if query:
            queryset = queryset.filter(
                Q(customer__last_name__icontains=query) |
                Q(customer__first_name__icontains=query)
            )
        return queryset


# ----------------------------------------------------------
# CREAR FACTURA
# ----------------------------------------------------------
class InvoiceCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = Invoice
    form_class = InvoiceForm
    template_name = "invoice/form.html"
    success_url = reverse_lazy("commerce:invoice_list")

    title1 = 'Ventas'
    title2 = 'Crear Nueva Venta'

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['products'] = Product.active_products.only('id', 'description', 'price', 'stock', 'iva')
        context['detail_sales'] = []
        context['save_url'] = reverse_lazy('commerce:invoice_create')
        context['invoice_list_url'] = self.success_url
        return context

    def post(self, request, *args, **kwargs):
        form = self.get_form()
        if not form.is_valid():
            return JsonResponse({"msg": form.errors}, status=400)

        data = request.POST
        try:
            with transaction.atomic():
                sale = Invoice.objects.create(
                    customer_id=int(data['customer']),
                    user=request.user,
                    payment_method=data['payment_method'],
                    issue_date=data['issue_date'],    # FECHA AUTOMÁTICA O ELEGIDA
                    subtotal=Decimal(data['subtotal']),
                    iva=Decimal(data['iva']),
                    total=Decimal(data['total']),
                )

                details = json.loads(data['detail'])
                for detail in details:
                    inv_det = InvoiceDetail.objects.create(
                        invoice=sale,
                        product_id=int(detail['id']),
                        quantity=Decimal(detail['quantify']),
                        price=Decimal(detail['price']),
                        iva=Decimal(detail['iva']),
                        subtotal=Decimal(detail['sub'])
                    )
                    inv_det.product.reduce_stock(Decimal(detail['quantify']))

                messages.success(request, f"Éxito al registrar la venta F#{sale.id}")
                return JsonResponse({"msg": "Éxito al registrar la venta Factura"}, status=200)

        except Exception as ex:
            return JsonResponse({"msg": str(ex)}, status=400)


# ----------------------------------------------------------
# EDITAR FACTURA
# ----------------------------------------------------------
class InvoiceUpdateView(LoginRequiredMixin, TitleContextMixin, UpdateView):
    model = Invoice
    form_class = InvoiceForm
    template_name = "invoice/form.html"
    success_url = reverse_lazy("commerce:invoice_list")

    title1 = 'Venta'
    title2 = 'Editar Venta'

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['products'] = Product.active_products.only('id', 'description', 'price', 'stock', 'iva')

        detail_sale = list(InvoiceDetail.objects.filter(invoice_id=self.object.id).values(
            "product", "product__description", "quantity", "price", "subtotal", "iva"
        ))

        context['detail_sales'] = json.dumps(detail_sale, default=custom_serializer)
        context['save_url'] = reverse_lazy('commerce:invoice_update', kwargs={"pk": self.object.id})
        context['invoice_list_url'] = self.success_url

        return context

    def post(self, request, *args, **kwargs):
        form = self.get_form()
        if not form.is_valid():
            return JsonResponse({"msg": form.errors}, status=400)

        data = request.POST
        try:
            sale = Invoice.objects.get(id=self.kwargs.get('pk'))

            with transaction.atomic():
                # Actualizar cabecera
                sale.customer_id = int(data['customer'])
                sale.user = request.user
                sale.payment_method = data['payment_method']
                if data.get('issue_date'):
                    sale.issue_date = data['issue_date']
                sale.subtotal = Decimal(data['subtotal'])
                sale.iva = Decimal(data['iva'])
                sale.total = Decimal(data['total'])
                sale.save()

                # Devolver stock → borrar detalles anteriores
                old_details = InvoiceDetail.objects.filter(invoice_id=sale.id)
                for det in old_details:
                    det.product.stock += det.quantity
                    det.product.save()

                old_details.delete()

                # Insertar nuevos detalles
                details = json.loads(request.POST['detail'])
                for detail in details:
                    inv_det = InvoiceDetail.objects.create(
                        invoice=sale,
                        product_id=int(detail['id']),
                        quantity=Decimal(detail['quantify']),
                        price=Decimal(detail['price']),
                        iva=Decimal(detail['iva']),
                        subtotal=Decimal(detail['sub'])
                    )
                    inv_det.product.reduce_stock(Decimal(detail['quantify']))

                messages.success(request, f"Venta F#{sale.id} actualizada correctamente.")
                return JsonResponse({"msg": "Éxito al actualizar la venta Factura"}, status=200)

        except Exception as ex:
            return JsonResponse({"msg": str(ex)}, status=400)


# ----------------------------------------------------------
# DETALLE (MODAL)
# ----------------------------------------------------------
class InvoiceDetailView(LoginRequiredMixin, TitleContextMixin, DetailView):
    model = Invoice
    template_name = 'invoice/detail_modal.html'
    context_object_name = 'invoice'

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        context = self.get_context_data(object=self.object)
        context['details'] = InvoiceDetail.objects.filter(invoice=self.object)
        html = render_to_string(self.template_name, context, request=request)
        return JsonResponse({'html': html})


# ----------------------------------------------------------
# ELIMINAR FACTURA
# ----------------------------------------------------------
class InvoiceDeleteView(LoginRequiredMixin, View):

    def post(self, request, pk, *args, **kwargs):
        try:
            with transaction.atomic():
                invoice = Invoice.objects.get(pk=pk)

                # Devolver stock
                details = InvoiceDetail.objects.filter(invoice=invoice)
                for d in details:
                    d.product.stock += d.quantity
                    d.product.save()

                details.delete()
                invoice.delete()

                return JsonResponse({'msg': f'✔ Factura N°{pk} eliminada correctamente.'}, status=200)

        except Invoice.DoesNotExist:
            return JsonResponse({'msg': '⚠ Factura no encontrada.'}, status=404)
        except Exception as ex:
            return JsonResponse({'msg': f'❌ Error al eliminar: {ex}'}, status=400)


# ----------------------------------------------------------
# ANULAR FACTURA
# ----------------------------------------------------------
class InvoiceAnnulView(LoginRequiredMixin, View):

    def post(self, request, pk, *args, **kwargs):
        try:
            with transaction.atomic():
                invoice = Invoice.objects.get(pk=pk)

                if not invoice.state:
                    return JsonResponse({'msg': '⚠ La factura ya está anulada.'}, status=400)

                # Revertir stock
                details = InvoiceDetail.objects.filter(invoice=invoice)
                for d in details:
                    d.product.stock += d.quantity
                    d.product.save()

                invoice.state = False
                invoice.save(update_fields=['state'])

                return JsonResponse({'msg': f'🚫 Factura N°{pk} anulada correctamente.'}, status=200)

        except Invoice.DoesNotExist:
            return JsonResponse({'msg': '⚠ Factura no encontrada.'}, status=404)
        except Exception as ex:
            return JsonResponse({'msg': f'❌ Error al anular: {ex}'}, status=400)
