# users/views.py

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import FormView, TemplateView
from django.shortcuts import render

from .forms import UserRegisterForm, UserUpdateForm, ProfileUpdateForm
from .models import Profile

# --- Registro ---
class RegisterView(FormView):
    template_name = 'login/register.html'
    form_class = UserRegisterForm
    success_url = reverse_lazy('login:login')

    def form_valid(self, form):
        form.save()
        messages.success(self.request, "Usuario creado correctamente. ¡Ahora puedes iniciar sesión!")
        return super().form_valid(form)



# --- Login ---
class LoginView(View):
    template_name = 'login/login.html'

    def get(self, request):
        return render(request, self.template_name)

    def post(self, request):
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)
            return redirect("core:home")  # igual que antes

        messages.error(request, "Usuario o contraseña incorrectos.")
        return render(request, self.template_name)
# --- Logout ---
class LogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('login:login')
# --- Perfil ---

class ProfileView(LoginRequiredMixin, TemplateView):
    template_name = 'login/profile.html'

    def get(self, request, *args, **kwargs):
        # Si no existe el profile, se crea
        if not hasattr(request.user, "profile"):
            Profile.objects.create(user=request.user)

        u_form = UserUpdateForm(instance=request.user)
        p_form = ProfileUpdateForm(instance=request.user.profile)

        return render(request, self.template_name, {
            'u_form': u_form,
            'p_form': p_form
        })

    def post(self, request, *args, **kwargs):
        u_form = UserUpdateForm(request.POST, instance=request.user)
        p_form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user.profile)

        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            messages.success(request, "Tu perfil ha sido actualizado.")
            return redirect("core:home")

        return render(request, self.template_name, {
            'u_form': u_form,
            'p_form': p_form
        })